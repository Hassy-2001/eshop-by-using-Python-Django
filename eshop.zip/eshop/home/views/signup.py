from django.shortcuts import render, redirect
from home.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'Signup.html')

    def post(self, request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # validation

        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }

        error_message = None

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            password=password,
                            phone=phone,
                            email=email)

        error_message = self.ValidateCustomer(customer)

        if not error_message:

            customer.password = make_password(customer.password)
            customer.register()
            return redirect('login page')

        else:
            dataset = {
                'error': error_message,
                'values': value
            }
            return render(request, "Signup.html", dataset)

    def ValidateCustomer(self,customer):
        error_message = None
        if (not customer.first_name):
            error_message = "First Name is Required !!"
        elif len(customer.first_name) < 4:
            error_message = "First Name First Must Have 4 Character !!"
        elif not customer.last_name:
            error_message = "Last Name is Required !!"
        elif len(customer.last_name) < 4:
            error_message = "Last Name First Must Have 4 Character !!"
        elif not customer.phone:
            error_message = "Phone Number is Required"
        elif len(customer.phone) < 11:
            error_message = "Phone Number Must Have 11 Digits"
        elif not customer.email:
            error_message = "Email Address is Required"
        elif not customer.password:
            error_message = "Password is Required"
        elif len(customer.password) < 8:
            error_message = "Password Must Have 8 Characters including UpperCase,LowerCase and Number"
        elif customer.isExists():
            error_message = "This Email Address is Already Registered !!"


        # saving

        return error_message
