from django.shortcuts import render, HttpResponse, redirect
from home.models.product import Product
from home.models.order import Order
from home.models.customer import Customer
from django.views import View


class CheckOut(View):
    def post(self, request):

        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        product = Product.get_products_by_id(list(cart.keys()))

        for product in product:

            order = Order(phone=phone, address=address, product=product,
                          customer=Customer(id=customer),price=product.price,
                          quantity=cart.get(str(product.id)))
            order.save()
        request.session['cart'] = {}
        return redirect('cart page')
